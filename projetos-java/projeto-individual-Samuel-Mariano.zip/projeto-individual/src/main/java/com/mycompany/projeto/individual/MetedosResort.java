/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto.individual;

import java.util.Scanner;

/**
 *
 * @author samue
 */

//Infelizmente só conseguir aplicar o metedo de dois cases
public class MetedosResort {
    public static void passeiosDoResort() {
        System.out.println("Passeios disponíveis:");
        System.out.println("- Passeio de Barco: R$ 100.00 por pessoa");
        System.out.println("- Caminhada Ecológica: R$ 50.00 por pessoa");
        System.out.println("- Passeio a Cavalo: R$ 80.00 por pessoa");
        System.out.println("- Trilhas na Mata: R$ 70.00 por pessoa");
    }
    
    public static void dadosDaSorte() {
        

        Integer numeroSorte = (int) (Math.random() * 6) + 1;

        if (numeroSorte == 1) {
            System.out.println("Infelizmente você não ganhou nada tente novamente!");
        } else if (numeroSorte == 2) {
            System.out.println("Parabéns! Você ganhou 20% de desconto em sua próxima hospedagem.");
        } else if (numeroSorte == 3) {
            System.out.println("Parabéns! Você ganhou um passeio de barco gratuito para duas pessoas.");
        } else if (numeroSorte == 4) {
            System.out.println("Parabéns! Você ganhou um jantar romântico gratuito para duas pessoas.");
        } else if (numeroSorte == 5) {
            System.out.println("Parabéns! Você ganhou um dia de spa gratuito para duas pessoas.");
        } else if (numeroSorte == 6) {
            System.out.println("Parabéns! Você ganhou um upgrade de quarto gratuito para sua próxima hospedagem.");
        }

        
    }
}


