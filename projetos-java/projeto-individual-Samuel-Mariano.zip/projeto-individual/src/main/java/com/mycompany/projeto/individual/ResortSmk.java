package com.mycompany.projeto.individual;

import java.util.Scanner;

/**
 *
 * @author samue
 */
public class ResortSmk {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        MetedosResort resort = new MetedosResort();
        Integer menu = 0;
        do {
            System.out.println("------------------------------\n"
                    + "|       Seja Bem-Vindo       |\n"
                    + "|           ao               |\n"
                    + "|        Resort Smk          |\n"
                    + "------------------------------\n"
                    + "|    Olá o que deseja saber? |\n"
                    + "|    Do nosso Resort Smk     |\n"
                    + "------------------------------\n"
                    + "| 1 - Reserva Quarto         |\n"
                    + "| 2 - Pacotes                |\n"
                    + "| 3 - Passeios do Risort     |\n"
                    + "| 4 - Dado sorte             |\n"
                    + "| 5 - Sair                   |\n"
                    + "------------------------------");
            menu = leitor.nextInt();
            switch (menu) {
                case 1:
                    System.out.println("Quantas pessoas vão ficar? ");
                    Double pessoas = leitor.nextDouble();

                    System.out.println("Quantos dias vão ficar? ");
                    Double dias = leitor.nextDouble();

                    System.out.println("Quantos quartos vão precisar? ");
                    Double quartos = leitor.nextDouble();

                    Double preco = quartos * 189.9 + dias * 150.0;
                    System.out.println(String.format("O preço total da reserva"
                            + " é R$ %.2f\n", preco));

                    Double desconto = pessoas * 50.0;
                    Double total = preco - desconto;
                    System.out.println(String.format("Com o desconto de R$ %.2f "
                            + "por pessoa, o valor final é R$ %.2f\n",
                            desconto, total));
                    break;
                case 2:
                    Scanner leitor2 = new Scanner(System.in);
                    System.out.println("Que pacote você esta procurando?\n"
                            + "1 - Lua de mel\n"
                            + "2 - Familia\n "
                            + "3 - Aventura");
                    Integer pacote = leitor.nextInt();
                    if (pacote == 1) {
                        System.out.println("\"Pacote Lua de Mel: R$ 1500.00\";");
                    } else if (pacote == 2) {
                        System.out.println("Pacote Família: R$ 2000.00");;
                    } else if (pacote == 3) {
                        System.out.println("Pacote Aventura: R$ 2500.00");
                    } else {
                        System.out.println("Pacote inválido. Tente novamente.");
                    }

                    break;
                case 3:
                    
                    break;
                case 4:
                    resort.dadosDaSorte();
                    break;
                case 5:
                    System.out.println("Obrigado por visitar o Resort Smk. "
                            + "Volte sempre!");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }
        } while (menu != 5);
    }
}
