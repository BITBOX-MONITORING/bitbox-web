package com.mycompany.mini.projeto.individual.matheus.lessa;

import java.util.Random;
import java.util.Scanner;

/**
 * @author Matheus Lessa
 */

public class MediaAluno {
    public static void main(String[] args) {
        Scanner leitor = new Scanner (System.in);
        CalcularMedia calculo = new CalcularMedia();
        Random random = new Random();
        
        int opcao = -1;
        
        while(opcao != 0){
            System.out.println("Selecione uma opção");
            System.out.println("1 - Calcular média");
            System.out.println("2 - Verificar aprovação");
            System.out.println("3 - Mini Quiz ");
            System.out.println("4 - Mini jogo");
            System.out.println("5 - Encerra o programa");
            
            opcao = leitor.nextInt();
            
            switch(opcao){
                case 1:
                    System.out.println("Digite a nota 1: ");
                    Double nota1 = leitor.nextDouble();
                    System.out.println("Digite a nota 2: ");
                    Double nota2 = leitor.nextDouble();
                    System.out.println("Digite a nota 3: ");
                    Double nota3 = leitor.nextDouble();
                    
                    Double media = calculo.calculoMedia(nota1, nota2, nota3);
                    String frase = String.format("Sua media final é: %.1f", media);
                    
                    System.out.println(frase);
                    
                    break;
                case 2:
                    media = 0.0;
                    
                    if(media >= 7){
                        System.out.println("Aprovado");
                    }else if(media < 6){
                        System.out.println("Reporvado");
                    }
                break;
                    
                
                case 3:
                    
                    System.out.println("O que é um JRE? ");
                    System.out.println("1 Ferramenta para interpretar o codigo em java");
                    System.out.println("2 Kit para desenvolvimento em java");
                    System.out.println("3 Ambiente de tempo de execução java");
                    
                    Integer resposta1 = leitor.nextInt();
                    switch (resposta1) {
                        case 3:
                            System.out.println("Correto");
                            break;
                        default:
                            System.out.println("Incorreto");
                    }
                    System.out.println();
                    
                    System.out.println("O que é JVM? ");
                    System.out.println("1 - Ambiente de tem de execução java");
                    System.out.println("2 - Ferramenta para interpretar o codigo em java");
                    System.out.println("3 - Kit para desenvolvimento em java");
                    Integer resposta2 = leitor.nextInt();
                    switch (resposta2) {
                        case 2:
                            System.out.println("Corretor");
                            break;
                        default:
                            System.out.println("Incorreto");
                    }
                    System.out.println();
                    
                    System.out.println("O que é JDK? ");
                    System.out.println("A - Kit para desenvolvimento em java");
                    System.out.println("B - Ferramenta para interpretar o codigo em java");
                    System.out.println("C - Ambiente de tem de execução java");
                    
                    Integer resposta3 = leitor.nextInt();
                    switch (resposta3) {
                        case 1:
                            System.out.println("Corretor");
                            break;
                        default:
                            System.out.println("Incorretor");
                    }
                    break;
                    
                    
                case 4:
                   int pontosUsuario = 0;
                   int pontosComputador = 0;
                   int opcao1 = -1;
                   
                    while(opcao1 != 0){
                        System.out.println("Mini jogo");
                        System.out.println("1 - Jogar");
                        System.out.println("0 - Sair");
                        opcao = leitor.nextInt();
                        
                        switch (opcao) {
                            case 1:
                                int dadoUsuario = random.nextInt(6)+1;
                                System.out.println("Você jogou o dado e tirou " + dadoUsuario);
                                pontosUsuario += dadoUsuario;
                                System.out.println("Você agora tem " + pontosUsuario + " pontos.");
                                
                                int dadoComputador = random.nextInt(6)+1;
                                System.out.println("O computador jogou o dado e tirou " + dadoComputador + " pontos.");
                                pontosComputador += dadoComputador;
                                System.out.println("O computador agora tem " + pontosComputador + " pontos.");
                                
                                if(pontosUsuario >= 100 || pontosComputador >= 100){
                                    System.out.println("Parabéns! Você ganhou com " + pontosUsuario + " pontos.");
                                }else if(pontosComputador > pontosUsuario){
                                    System.out.println("O computador ganhou " + pontosComputador + " pontos.");
                                }else{
                                    System.out.println("Empate! Ambos os jogadores têm " + pontosUsuario + " pontos.");
                                }
                                break;
                                
                            case 0: 
                                System.out.println("Saiu do mini jogo");
                                break;
                            default:
                                System.out.println("Entrada inválida. Tente novamente");
                        }
                }
                    
                case 5: 
                    System.out.println("Programa encerrado");
                    break;
            }
        }
                
    }
}
