package com.mycompany.mini.projeto.individual.matheus.lessa;

import java.io.InputStream;

/**
 * @author Matheus Lessa
 */

public class CalcularMedia {
    Double calculoMedia (Double nota1, Double nota2, Double nota3){
        Double media = (nota1 + nota2 + nota3) / 3;
        return media;
    }
}
