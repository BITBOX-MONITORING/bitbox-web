/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projeto.individual.livia.leal;

import java.util.Scanner;

/**
 *
 * @author livia
 */
public class ProjetoIndividualLiviaLeal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner usuario = new Scanner (System.in);
        
        
        Integer escolha ;
        Integer florEscolha;
        Double pagamentoFinal = 0.00;

        do{                
         System.out.println("--------------------------------------------");
         System.out.println("     Floricultura Bela-Dona!                ");
         System.out.println("--------------------------------------------");
         System.out.println("Escolha uma opção para prosseguirmos: ");
         System.out.println("1- Comprar flores unitárias\n" +
                            "2- Flores com presentes\n"+
                            "3- Finalizar compra\n" +
                            "4- Jogo" +
                            "0- Sair");
        
         escolha = usuario.nextInt();
         
            Double margaridas = 14.99;
            Double belaDona = 16.99;
            Double girassois = 16.99;
            Double rosasVermelhas = 29.99;
            
        switch(escolha){
                
            case 1 :
                do{
                System.out.println("Escolha uma opção de flor que deseja: \n" +
                        "1- Margaridas\n"+
                        "2- Bela-Dona\n" +
                        "3- Rosas Vermelhas\n" +
                        "4- Girassois\n"+
                        "0- Voltar ao menu inicial");
                florEscolha= usuario.nextInt();
                switch(florEscolha){
                    case 1 :
                        System.out.println("Sua escolha foi: Margaridas\n"
                        + "Insira quantas flores irá comprar");
                        Integer qtdMargaridas = usuario.nextInt();
                        pagamentoFinal+= (qtdMargaridas * margaridas); 
                        System.out.println("Adicionado ao carrinho!\n");
                        break;
                    case 2 :
                        System.out.println("Sua escolha foi: Bela-Dona\n"
                        + "Insira quantas flores irá comprar");
                        Integer qtdBelaDona = usuario.nextInt();
                        pagamentoFinal+= (qtdBelaDona * belaDona);
                        System.out.println("Adicionado ao carrinho!\n");
                break;
                    case 3 :
                        System.out.println("Sua escolha foi: Rosas Vermelhas\n" + 
                                "Insira quantas flores irá comprar");
                        Integer qtdRosasVermelhas = usuario.nextInt();
                        pagamentoFinal+= (qtdRosasVermelhas * rosasVermelhas);
                        System.out.println("Adicionado ao carrinho!\n");
                break;
                    case 4 :
                        System.out.println("Sua escolha foi: Girassois\n"
                        + "Insira quantas flores irá comprar");
                        Integer qtdGirassois= usuario.nextInt();
                        pagamentoFinal+= (qtdGirassois * girassois);
                        System.out.println("Adicionado ao carrinho!\n");
                break;
                    case 0 :
                        System.out.println("Voltando para o menu inicial!\n");
                        break;
                }
                }while(florEscolha != 0);
                break;
            case 2:
               System.out.println("Selecione o presente:\n"+ 
                        "1- Rosas com bombons\n" +
                        "2- Margaridas com balões\n"+
                        "3- Bella-dona com caneca e doces\n"+
                        "4- Girassois com balões, canecas e bombons");
                Integer escolhaPresente = usuario.nextInt();
                
                if(escolhaPresente == 1){
                    pagamentoFinal+= 50.00;   
                    System.out.println("Adicionado ao carrinho!\n");
                    break;
                }else if(escolhaPresente == 2){
                    pagamentoFinal+= 35.00;
                    System.out.println("Adicionado ao carrinho!\n");
                    break;
                }else if(escolhaPresente == 3){
                    pagamentoFinal+= 40.00;
                    System.out.println("Adicionado ao carrinho!\n");
                    break;
                }else{
                    pagamentoFinal+= 65.00;
                    System.out.println("Adicionado ao carrinho!\n");
                }
                System.out.println("Compra realizada!");
                break;
            case 3:
                System.out.println(String.format("O valor total da sua compra foi %.2f\n", pagamentoFinal));
                break;
            case 4:
            
                
            case 0:
                System.out.println("Até logo!\n"
                                + "Volte sempre!");
                break;
            default:
                System.out.println("Valor inválido, insira novamente um número do menu"); 
        }
        
        }while(escolha != 0);
        }
              
    }
    

