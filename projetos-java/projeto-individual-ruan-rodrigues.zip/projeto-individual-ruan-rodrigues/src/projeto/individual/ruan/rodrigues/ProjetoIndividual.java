/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projeto.individual.ruan.rodrigues;

import java.util.Scanner;
import java.time.Year;

/**
 *
 * @author Ruanc
 */
public class ProjetoIndividual {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        MenuMethods menuMethods = new MenuMethods();
        Year year = Year.now();

        Integer menuOption,
                nTerm,
                yearBirthday,
                yearCurrent = year.getValue();
        
        Double n1,
               n2,
               n3,
               media;
        
        String name,
               statusCNH;

        do {
            System.out.println("\n------------------------------\n"
                    + "|            Menu            |\n"
                    + "------------------------------\n"
                    + "|  Olá, o que deseja fazer?: |\n"
                    + "------------------------------\n"
                    + "|  1 - Sequência Fibonacci   |\n"
                    + "|  2 - Tirar CNH             |\n"
                    + "|  3 - Calcular média        |\n"
                    + "|  0 - Sair                  |\n"
                    + "------------------------------");
            menuOption = sc.nextInt();
            
            switch(menuOption){
                case 1:
                    System.out.println("Até que termo você gostaria da ver a sequência?:");
                    nTerm = sc.nextInt();
                    
                    menuMethods.calculateFibonacci(nTerm);
                    break;
                    
                case 2:
                    System.out.println("Qual seu nome?:");
                    name = sc.next();
                    
                    System.out.println("Em que ano você nasceu?:");
                    yearBirthday = sc.nextInt();
                    
                    statusCNH = menuMethods.retirarCNH(name, yearBirthday, yearCurrent);
                    System.out.println(statusCNH);
                    
                case 3:
                    System.out.println("Digite o 1º número:");
                    n1 = sc.nextDouble();
                    
                    System.out.println("Digite o 2º número:");
                    n2 = sc.nextDouble();
                    
                    System.out.println("Digite o 3º número:");
                    n3 = sc.nextDouble();
                    
                    media = menuMethods.calcularMedia(n1, n2, n3);
                    
                    System.out.println(String.format("Média: %.2f", media));  
                    
                case 0:
                    System.out.println("Adeus :)");
                    break;
                    
                default:
                    System.out.println("Opção inválida, tente novamente:");
                    
            }

        } while (menuOption != 0);

    }

}
