/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projeto.individual.ruan.rodrigues;

/**
 *
 * @author Ruanc
 */
public class MenuMethods {

    void calculateFibonacci (Integer nTerm) {
        Integer currentNumber = 0,
                prevNumber = 1;

        for (int i = 0; i < nTerm; i++) {
            currentNumber += prevNumber;
            prevNumber = currentNumber - prevNumber;
            System.out.print(currentNumber + ", ");
        }
    }
    
    String retirarCNH (String name, Integer yearBirthday, Integer yearCurrent){
        
        Integer age = yearCurrent - yearBirthday;
        
        String statusCNH = age > 18 ? "Pode retirar CNH!" : "Por enquanto, só Hotwheels :(";
        
        return statusCNH;
        
    }
    
    Double calcularMedia(Double n1, Double n2, Double n3){
        return (n1 + n2 + n3) / 3;
    }

}
