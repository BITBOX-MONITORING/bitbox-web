
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;
import java.util.Random;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author thiag
 */
public class Projetinho {

    public static void main(String[] args) {
        Scanner jogo = new Scanner(System.in);
        Scanner leitor = new Scanner(System.in);
        Scanner input = new Scanner(System.in);
        Random random = new Random();

        Scanner leitor02 = new Scanner(System.in);
        System.out.println("Olá, qual seu nome ?");
        String nome = leitor.next();
        System.out.println("Insira um numero qualquer");
        Double numero = leitor.nextDouble();
        System.out.println("Insira um numero do menu para começarmos\n 1-soma"
                + "\n 2-é primo ?\n 3-Qual operação é mais utilizada\n"
                + "4-insira 0 para encerrar o programa\n "
                + "5 para jo ken po");
        Integer menu = leitor.nextInt();

        while (menu > 0) {

            switch (menu) {

                case 1:

                    for (int i = 0; i <= 10; i++) {
                        System.out.print(numero + "+");
                        System.out.print(i);

                        Double soma = numero + i;
                        System.out.println("= " + (soma) + "\n");

                    }

                    System.out.println("selecione menu novamente");
                    menu = leitor.nextInt();

                    break;

                case 2:

                    Integer contador = 0;

                    for (int i = 0; i < 10; i++) {

                        if (numero % i == 0.0) {
                            contador++;

                        }
                    }
                    if (contador <= 2) {
                        System.out.println("É primo");
                    } else {
                        System.out.println("Nao é primo");
                    }
                    System.out.println("selecione menu novamente");
                    menu = leitor.nextInt();
                    break;

                case 3:

                    System.out.println("Quiz qual operacao matematica é mais utilizada ?");
                    String resposta = leitor.next();

                    if (resposta.equals("multiplicacao")) {
                        System.out.println("Resposta certa");
                    } else if (resposta.equals("subtracao")) {
                        System.out.println("Resposta errada");
                    } else if (resposta.equals("soma")) {
                        System.out.println("Resposta errada");
                    } else if (resposta.equals("divisao")) {
                        System.out.println("Reposta errada");
                    }
                    System.out.println("selecione menu novamente");
                    menu = leitor.nextInt();
                    break;

                case 4:
                    menu = 0;
                    break;

                case 5:

                    String[] opcoes = {"pedra", "papel", "tesoura"};
                    Integer jogador1,
                     jogador2;
                    String correto;

                    do {

                        System.out.println("Escolha uma opção: 0 - Pedra, 1 - Papel, 2 - Tesoura");
                        jogador1 = input.nextInt();

                        jogador2 = random.nextInt(3);
                        System.out.println("Jogador 2 escolheu: " + opcoes[jogador2]);

                        if (jogador1 == jogador2) {
                            System.out.println("Empate!");
                        } else if ((jogador1 == 0 && jogador2 == 2)
                                || (jogador1 == 1 && jogador2 == 0)
                                || (jogador1 == 2 && jogador2 == 1)) {
                            System.out.println("Jogador 1 ganhou!");
                        } else {
                            System.out.println("Jogador 2 ganhou!");
                        }

                        System.out.println("Deseja continuar jogando? (s/n)");
                        correto = input.next();

                    } while (correto.equals("s"));
                    

                    System.out.println("selecione menu novamente");
                    menu = leitor.nextInt();

                    break;

            }

        }
    }
}
