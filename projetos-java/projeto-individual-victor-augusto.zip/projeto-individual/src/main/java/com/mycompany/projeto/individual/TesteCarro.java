package com.mycompany.projeto.individual;

import java.util.Scanner;

/**
 *
 * @author augus
 */
public class TesteCarro {

    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);
        Carro metodoCarro = new Carro();

        Integer numeroDigitado;
        String carroGanhado = "";

        do {

            System.out.println("\n Bem vindo ao Sistema do Vitinho!!");
            System.out.println("\n");

            System.out.println("   1 - Veja quanto seu carro faz por litro");
            System.out.println("   2 - Ganhe um carro!");
            System.out.println("   3 - Conheça mais sobre as partes de um carro");
            System.out.println("   4 - Aposte uma corrida!");
            System.out.println("   0 - Sair");

            numeroDigitado = leitor.nextInt();

            switch (numeroDigitado) {
                case 1:
                    System.out.println("Infome quantos litros abasteceu no posto:");
                    Double litroInserido = leitor.nextDouble();

                    System.out.println("Informe quantos kms seu carro andou com o tanque:");
                    Double kmInserido = leitor.nextDouble();

                    metodoCarro.retornaDicas(kmInserido, litroInserido);

                    break;
                case 2:

                    System.out.println(metodoCarro.retornaCarroGanhado(carroGanhado, numeroDigitado));

                    break;
                case 3:

                    System.out.println("Escolha a parte que deseja saber mais!");

                    System.out.println("   1 - Motores");
                    System.out.println("   2 - Transmissão");
                    System.out.println("   3 - Suspensão");
                    System.out.println("   4 - Direção");

                    numeroDigitado = leitor.nextInt();
                    
                    metodoCarro.retornaInfomacoes(numeroDigitado);

                    break;
                case 4:

                    System.out.println("Qual o nome do primeiro player?");
                    String jogador1 = leitor.next();

                    System.out.println("Qual o nome do segundo player?");
                    String jogador2 = leitor.next();

                    System.out.println("Qual o nome do terceiro player?");
                    String jogador3 = leitor.next();
                    
                    System.out.println(metodoCarro.retornaResultadoCorrida(jogador1,jogador2,jogador3));
                    
                    break;
                case 0:
                    System.out.println("Até logo! Volte sempre xD");
                    break;
            }
        } while (numeroDigitado != 0);

    }
}
