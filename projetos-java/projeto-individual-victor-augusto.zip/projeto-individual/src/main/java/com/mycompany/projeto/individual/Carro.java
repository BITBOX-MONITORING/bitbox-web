/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto.individual;

import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author augus
 */
public class Carro {

    String retornaCarroGanhado(String carroGanhado, Integer sorteadoDoCarro) {

        sorteadoDoCarro = ThreadLocalRandom.current().nextInt(1, 11);
        String carroSorteado = "";

        if (sorteadoDoCarro.equals(1)) {
            carroGanhado = "Celta";
        } else if (sorteadoDoCarro.equals(2)) {
            carroGanhado = "Opala";
        } else if (sorteadoDoCarro.equals(3)) {
            carroGanhado = "Cruzer";
        } else if (sorteadoDoCarro.equals(4)) {
            carroGanhado = "Lancer";
        } else if (sorteadoDoCarro.equals(5)) {
            carroGanhado = "HB20";
        } else if (sorteadoDoCarro.equals(6)) {
            carroGanhado = "Omega";
        } else if (sorteadoDoCarro.equals(7)) {
            carroGanhado = "Elantra";
        } else if (sorteadoDoCarro.equals(8)) {
            carroGanhado = "Sonata";
        } else if (sorteadoDoCarro.equals(9)) {
            carroGanhado = "Camaro";
        } else if (sorteadoDoCarro.equals(10)) {
            carroGanhado = "Chevette";
        }
        System.out.println("\n");
        carroSorteado = ("Voçê ganhou um " + carroGanhado + "!");
        System.out.println("\n");

        return carroSorteado;
    }

    void retornaDicas(Double kmInserido, Double litroInserido) {
        Double calcularKmPorLitro = kmInserido / litroInserido;

        System.out.println(String.format(String.format(" Seu carro faz %.2f por litro!", calcularKmPorLitro)));

        if (calcularKmPorLitro >= 2 && calcularKmPorLitro <= 4) {
            System.out.println("\n Muito preocupante! \n ");
            System.out.println("Dica:\n"
                    + "Procure fazer uma lipeza nos bicos injetores");
        } else if (calcularKmPorLitro >= 5 && calcularKmPorLitro <= 7) {
            System.out.println("\n  Preocupante! \n ");
            System.out.println("Dica:\n"
                    + "Procure fazer a troca dos cabos e velas");
        } else if (calcularKmPorLitro >= 5 && calcularKmPorLitro <= 7) {
            System.out.println("\n Razoavel! \n ");
            System.out.println("Dica:\n"
                    + "Procure andar sempre a baixo dos 80 km/h");
        } else if (calcularKmPorLitro >= 8 && calcularKmPorLitro <= 11) {
            System.out.println("\n Bom! \n");
            System.out.println("Dica:\n"
                    + "Procure não ficar segurando seu carro com a embreagem e sem manter o carro acelerado em subidas!");
        } else if (calcularKmPorLitro >= 12 && calcularKmPorLitro <= 15) {
            System.out.println("\n Bom! \n");
            System.out.println("Dica:\n"
                    + "Seu carro se sai muito bem! Mas sempre verifique se os cabos e as velas estão boas");
        }
    }

    void retornaInfomacoes(Integer numeroDigitado) {

        switch (numeroDigitado) {
            case 1:
                
                System.out.println("""
                                   Motores
                                    Os motores de combustão interna funcionam queimando combustível dentro de um cilindro, 
                                    criando uma explosão que empurra um pistão para cima e para baixo, gerando energia para movimentar 
                                    o carro.
                                    Os motores elétricos, por outro lado, usam eletricidade para gerar energia. Eles são alimentados 
                                    por uma bateria e convertem a energia elétrica em movimento. Os motores elétricos são altamente eficientes 
                                    e silenciosos, e estão se tornando cada vez mais populares à medida que a tecnologia de bateria melhora. 
                                   """);
                break;
            case 2:
                
                System.out.println("""
                                    Transmissão
                                    A transmissão de um carro é responsável por transmitir a potência gerada pelo motor para \n"
                                    as rodas, permitindo que o carro se mova. Ela é composta por diversas engrenagens que trabalham em "
                                    conjunto para proporcionar diferentes relações de marcha, permitindo que o motor trabalhe de forma "
                                    eficiente em diferentes situações, como subidas ou estradas planas. Os principais tipos de transmissão "
                                    são a manual"
                                    ,onde o motorista seleciona as marchas, e a automática, que realiza essa seleção de forma automática."
                                   """);
                break;
            case 3:

                System.out.println("""
                            Suspensão
                            A suspensão de um carro é responsável por absorver as irregularidades do terreno,
                            proporcionando uma condução mais suave e confortável, além de melhorar a estabilidade e segurança
                            do veículo.
                           """);
                break;
            case 4:
                System.out.println("""
                            Direção  
                            A direção de um carro é responsável por permitir que o motorista controle a direção do veículo.
                            Ela é composta por diversos componentes, como a caixa de direção, a coluna de direção, as barras de
                            direção e as terminais de direção, que trabalham em conjunto para transmitir o movimento do volante às 
                            rodas. Existem diferentes tipos de direção, como a mecânica, a hidráulica, a elétrica e a assistida, que
                            proporcionam diferentes níveis de conforto e facilidade na hora de conduzir o veículo. 
                            """);
                break;
        }
    }
    
    String retornaResultadoCorrida (String jogador1, String jogador2, String jogador3){
                    Integer ponto01 = 0;
                    Integer ponto02 = 0;
                    Integer ponto03 = 0;
                    
                    String frase;

                    for (int i = 1; i < 10; i++) {
                        Integer valorPlayer01 = ThreadLocalRandom.current().nextInt(1, 101);
                        Integer valorPlayer02 = ThreadLocalRandom.current().nextInt(1, 101);
                        Integer valorPlayer03 = ThreadLocalRandom.current().nextInt(1, 101);

                        System.out.println(String.format("Volta %d", i));

                        if (valorPlayer01 > valorPlayer02 && valorPlayer01 > valorPlayer03) {
                            System.out.println("O " + jogador1 + " foi o mais rapido da volta!");
                            ponto01++;
                        } else if (valorPlayer02 > valorPlayer01 && valorPlayer02 > valorPlayer03) {
                            System.out.println("O " + jogador2 + " foi o mais rapido da volta!");
                            ponto02++;
                        } else {
                            System.out.println("O " + jogador3 + " foi o mais rapido da volta!");
                            ponto03++;
                        }

                    }

                    if (ponto01 > ponto02 && ponto01 > ponto03) {
                        frase = "O " + jogador1 + " ganhou com um total de " + ponto01 + " pontos";
                    } else if (ponto02 > ponto01 && ponto02 > ponto03) {
                        frase = "O " + jogador2 + " ganhou com um total de " + ponto02 + " pontos";
                    } else {
                        frase = "O " + jogador3 + " ganhou com um total de " + ponto03 + " pontos";
                    }
        return frase;
  
        }

}
